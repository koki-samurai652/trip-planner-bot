Memo
# ライブラリインストール

```bash
pip install openai -t .
pip install line-bot-sdk -t .
```

